print("Basics:")
List = ["Kayhan" , "KING" , "said", "hello","$"]
print(List[0])
print(List[2])
print(List[3])

List1 = [2,5,77,74,3,6]
print("List Number 1:")
print (List1)

List1 = [2,5,77,74,3,6]
print("List Number 1 Reversed:")
List1.reverse()
print (List1)

print("Concatenated list:")
list1 = [2,5,77,74,3,6]
list1.append ('6,3,74,77,5,20')
print(list1)

Print("Numbers Squared:")
Numbers = [2, 5, 77, 74, 3,6]

squared_numbers = [number ** 2 for number in numbers]

print(squared_numbers)












